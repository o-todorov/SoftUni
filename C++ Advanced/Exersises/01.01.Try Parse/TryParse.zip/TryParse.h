
#ifndef TRYPARSE_H

#include <string>

extern bool tryParse(std::string& input, int& a);

#define TRYPARSE_H
#endif // !TRYPARSE_H
