#ifndef ORDERED_INSERTER_H 
#define ORDERED_INSERTER_H

#include "Company.h"
#include <vector>

class OrderedInserter {
private:
	std::vector<const Company*>* comps;
public:
	OrderedInserter(std::vector<const Company*>& companies):
		comps (& companies)
	{

	}

void insert( const Company* companyPtr) {

	int id = companyPtr->getId();
	int pos = 0;

	for ( size_t i = 0; i < (*comps).size(); i++ ) {

		if ( id < (*comps)[i]->getId() ) {
			pos = i;
			break;
		}
		pos = (*comps).size();
	}

	(*comps).insert((*comps).begin() + pos, companyPtr);

	}
};


#endif // !ORDERED_INSERTER_H
